ServerEvents.tags('entity_type', e => {

})