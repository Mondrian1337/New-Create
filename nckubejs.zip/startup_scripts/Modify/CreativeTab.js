StartupEvents.modifyCreativeTab('kubejs:tab', e => {
	e.setDisplayName(Text.translate('itemGroup.new_create.tab'))
	e.setIcon('new_create:cast_iron_ingot')
})